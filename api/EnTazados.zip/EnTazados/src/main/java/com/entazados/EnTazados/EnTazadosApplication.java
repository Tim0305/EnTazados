package com.entazados.EnTazados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnTazadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnTazadosApplication.class, args);
	}

}
